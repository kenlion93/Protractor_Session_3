import {browser, by, element} from 'protractor'
import { async } from 'q';
describe ('Login Banking',function(){
    it('should be navigated to Banking when login with valid account', async function(){
        // automate each step
        await browser.get('http://www.way2automation.com/angularjs-protractor/banking/#/login')
        await browser.manage().window().maximize()
        await browser.sleep(2000)

        //verify
        await browser.element(by.xpath("//button[@ng-click='manager()']")).click()
        //add customer
        await browser.element(by.xpath("//button[@ng-click='addCust()']")).click()
        await browser.element(by.xpath("//input[@ng-model='fName']")).sendKeys("Jason")
        await browser.element(by.xpath("//input[@ng-model='lName']")).sendKeys("Le")
        await browser.element(by.xpath("//input[@ng-model='postCd']")).sendKeys("001")
        await browser.element(by.xpath("//button[@type='submit']'")).click()

        //expected check alert message
        

        //open account
        await browser.element(by.xpath("//button[@ng-click='openAccount()']")).click()
        //find customer dropdown
        await browser.element(by.xpath("//select[@id='userSelect']")).click()
        await browser.element(by.xpath("//option[contains(text(),'Hermoine Granger')]")).click()
        //find currency dropdown
        await browser.element(by.xpath("//select[@id='currency']")).click()
        await browser.element(by.xpath("//option[contains(text(),'Dollar')]")).click()

        await browser.element(by.xpath("//button[@type='submit']")).click()

        await browser.sleep(2000)
    })
})