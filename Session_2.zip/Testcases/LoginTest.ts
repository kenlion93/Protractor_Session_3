import { async } from "q";
import { LoginPage } from "../PageObjects/LoginPage";
import { browser } from "protractor";

describe ('Customer login', function(){
    let loginPage : LoginPage

    beforeEach(async function(){
        loginPage = new LoginPage(browser)

        await browser.get('http://www.way2automation.com/angularjs-protractor/banking/#/login')
        await browser.manage().window().maximize()
    })


    fit("should be displayed when login with valid account", async function(){
        let customerName = "Hermoine Granger"
        console.log("Step 1: login with customer account")
        await loginPage.selectCustomerRole()
        await loginPage.selectCustomerName(customerName)
        await loginPage.selectLogin()

        await browser.sleep(2000)
    })


})