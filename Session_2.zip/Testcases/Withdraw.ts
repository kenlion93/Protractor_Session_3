import { browser, by } from "protractor";
import { protractor } from "protractor/built/ptor";

describe ('Customer Login', function(){
    it('should be navigated to Customer when login and withdraw account', async function(){
         // automate each step
         await browser.get('http://www.way2automation.com/angularjs-protractor/banking/#/login')
         await browser.manage().window().maximize()
         await browser.sleep(2000)


         await browser.element(by.xpath("//button[@ng-click ='customer()']")).click()
         
         //select Your Name
         await browser.element(by.xpath("//select[@ng-model ='custId']")).click()
         await browser.element(by.xpath("//option[contains(text(),'Ron Weasly')]")).click()
         await browser.element(by.xpath("//button[@class='btn btn-default']")).click()

         //click Withdraw
         await browser.element(by.xpath("//button[@ng-click='withdrawl()']")).click()
         await browser.element(by.xpath("//input[@ng-model='amount']")).sendKeys('50')
         await browser.element(by.xpath("//button[@type = 'submit']")).click()
    })
})