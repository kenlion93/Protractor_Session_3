export class HomePage{
    //define element on Home page

    deposit_btn:string
    withdraw_btn:string
    submit_btn:string

}