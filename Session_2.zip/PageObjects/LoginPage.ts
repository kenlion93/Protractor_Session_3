import { ProtractorBrowser, browser, by } from "protractor";

export class LoginPage{
    //define element on Login page
    customerRole:string
    bankManagerRole:string
    yourName_ddl:string
    login_btn:string
    
    constructor(browser:ProtractorBrowser){
        this.customerRole = "//button[@ng-click ='customer()']"
        this.yourName_ddl = "//select[@ng-model ='custId']"
        this.login_btn = "//button[@class='btn btn-default']"

        //bank manager role
        this.bankManagerRole = "//button[@ng-click='manager()']"

    }

    async selectCustomerRole(){
        await browser.element(by.xpath(this.customerRole)).click
    }   
    
    async selectCustomerName(customerName:string){
        console.log("Login page: select customer name"+customerName)
        await browser.element(by.xpath(this.yourName_ddl)).sendKeys(customerName)
    }

    async selectLogin(){
        await browser.element(by.xpath(this.login_btn)).click()
    }
}