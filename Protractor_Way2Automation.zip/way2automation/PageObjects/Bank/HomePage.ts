import { ProtractorBrowser, by, ElementFinder, browser } from "protractor";

export class HomePage{
    //account view
    accountNum_ddl:string
    welcome_msg: string
    
    //deposit tab
    deposit_tab:string
    depositedAmount:string
    deposit_btn:string
    deposit_msg:string

    //transaction tab
    transactions_tab:string
    firstTransaction:string

    //withdrawl tab
    withdrawl_tab:string
    withdrawlAmount:string
    withdrawl_btn:string
    withdrawl_msg:string
    /**
     *
     */
    constructor(browser: ProtractorBrowser) {
        //account view
        this.accountNum_ddl = "//select[@name='accountSelect']"
        this.welcome_msg = "//strong[contains(text(),'Welcome')]/span"
        
        //deposit tab
        this.deposit_tab = "//div[@ng-hide='noAccount']/button[contains(text(), 'Deposit')]"
        this.depositedAmount = "//label[text()='Amount to be Deposited :']/following::input"
        this.deposit_btn = "//button[text()='Deposit']"
        this.deposit_msg = "//span[text()='Deposit Successful']"

        //transaction tab
        this.transactions_tab = "//button[contains(text(), 'Transactions')]"
        this.firstTransaction = "//tr[@id='anchor0']"

        //withdrawl tab
        this.withdrawl_tab = "//button[contains(text(), 'Withdrawl')]"
        this.withdrawlAmount = "//label[text()='Amount to be Withdrawn :']/following::input"
        this.withdrawl_btn = "//button[text()='Withdraw']"
        this.withdrawl_msg = "//span[text()='Transaction successful']"   
    }

    async navigateToTransactionView(){
        await browser.element(by.xpath(this.transactions_tab)).click()
    }

    async navigateToDepositView(){
        await browser.element(by.xpath(this.deposit_tab)).click()
    }

    async inputDepositAmount(data:string){
        console.log("HomePage: deposit with amount " + data)
        await browser.element(by.xpath(this.depositedAmount)).sendKeys(data)
        
    }

    async selectDeposit(){
        await browser.element(by.xpath(this.deposit_btn)).click()
    }

    async navigateToWithdrawlView(){
        await browser.element(by.xpath(this.withdrawl_tab)).click()
    }

    async inputWithdrawlAmount(withdrawlAmount:string){
        console.log("HomePage: withdrawl with amount " + withdrawlAmount)
        await browser.element(by.xpath(this.withdrawlAmount)).sendKeys(withdrawlAmount)
    }

    async selectWithdrawl(){
        await browser.element(by.xpath(this.withdrawl_btn)).click()        
    }
    async verifyFirstTransaction(expectedResult:string){
        await expect (browser.element(by.xpath(this.firstTransaction)).getText()).toEqual(expectedResult)        
    }

    async verifyDepositMsg(){
        await expect (browser.element(by.xpath(this.deposit_msg)).isDisplayed()).toBe(true)
    }

    async verifyWithdrawlMsg(){
        await expect (browser.element(by.xpath(this.withdrawl_msg)).isDisplayed()).toBe(true)        
    }

    async getWelcomeMsg():Promise<string>{
        return await browser.element(by.xpath(this.welcome_msg)).getText()
    }
}