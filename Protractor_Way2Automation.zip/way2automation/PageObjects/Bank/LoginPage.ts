import { ElementFinder, ProtractorBrowser, browser, by } from "protractor";

export class LoginPage{

    //define element on Login page
    customerRole: string
    bankManagerRole:string
    yourName_ddl: string
    login_btn: string
    constructor(browser:ProtractorBrowser){
        //customer login
        this.customerRole = "//button[text()='Customer Login']"
        this.yourName_ddl = "//select[@id='userSelect']"
        this.login_btn = "//button[text()='Login']"
        
        //bank manager login
        this.bankManagerRole = "//button[text()='Bank Manager Login']"
    }

    async selectCustomerRole(){
        await browser.element(by.xpath(this.customerRole)).click()
    }
    
    async selectCustomerName(customerName: string){
        console.log("LoginPage: select customer name " + customerName)
        await browser.element(by.xpath(this.yourName_ddl)).sendKeys(customerName)
        
    }

    async selectLogin(){
        await browser.element(by.xpath(this.login_btn)).click()
    }
}