import { browser, by, protractor } from "protractor";
import { LoginPage } from "../../PageObjects/Bank/LoginPage";
import { HomePage } from "../../PageObjects/Bank/HomePage";

describe("Customer ", function(){
    var loginPage:LoginPage
    var homePage:HomePage

    beforeEach(async function(){
        loginPage = new LoginPage(browser)
        homePage = new HomePage(browser)

        await browser.manage().window().maximize()
        await browser.get("http://www.way2automation.com/angularjs-protractor/banking/#/login")
    })

    it("can deposit their account in XYZ bank", async function(){
        var customerName="Harry Potter"
        var depositAmount ="3000"
        console.log("STEP 1: login with customer account " + customerName)
        await loginPage.selectCustomerRole()
        await loginPage.selectCustomerName(customerName)
        await loginPage.selectLogin()

        console.log("STEP 2: deposit with amount " + depositAmount)
        await homePage.navigateToDepositView()
        await homePage.inputDepositAmount(depositAmount)
        await homePage.selectDeposit()

        console.log("STEP 3: verify message \"Deposit Sucessfully\" should be shown")
        await homePage.verifyDepositMsg()
        await browser.sleep(5000)

    })
    
    it("can login and view their Transactions for XYZ bank", async function(){
        var customerName="Hermoine Granger"
        console.log("STEP 1: login with customer account " + customerName)
        await loginPage.selectCustomerRole()
        await loginPage.selectCustomerName(customerName)
        await loginPage.selectLogin()

        console.log("STEP 2: verify the first transaction customer account " + customerName)
        await homePage.navigateToTransactionView()
        await homePage.verifyFirstTransaction("Jan 1, 2015 12:00:00 AM 30 Credit")
        await browser.sleep(5000)

    })

    

    it("can withdrawl their account in XYZ bank", async function(){
        var customerName="Hermoine Granger"
        var withdrawlAmount ="30"
        console.log("STEP 1: login with customer account " + customerName)
        await loginPage.selectCustomerRole()
        await loginPage.selectCustomerName(customerName)
        await loginPage.selectLogin()

        console.log("STEP 2: withdrawl with amount " + withdrawlAmount)
        await homePage.navigateToWithdrawlView()
        await homePage.inputWithdrawlAmount(withdrawlAmount)
        await homePage.selectWithdrawl()

        console.log("STEP 3: verify msg \"Withdrawl successful\" should be displayed")
        await homePage.verifyWithdrawlMsg()
        await browser.sleep(5000)

    })
    afterEach( async function() {
    })
})