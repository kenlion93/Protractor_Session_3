import { LoginPage } from "../../PageObjects/Bank/LoginPage";
import { browser } from "protractor";
import { HomePage } from "../../PageObjects/Bank/HomePage";

describe("Welcome <username> message ", function(){
    let loginPage: LoginPage
    let homePage: HomePage

    beforeEach(async function(){
        loginPage = new LoginPage(browser)      
        homePage = new HomePage(browser)

        await browser.manage().window().maximize()
        await browser.get("http://www.way2automation.com/angularjs-protractor/banking/#/login")
    })

    it("should be displayed when login with valid account", async function(){
        let customerName="Harry Potter"
        console.log("STEP 1: login with customer account " + customerName)
        await loginPage.selectCustomerRole()
        await loginPage.selectCustomerName(customerName)
        await loginPage.selectLogin()

        console.log("STEP 2: verify welcome message with username " + customerName)
        await expect(homePage.getWelcomeMsg()).toContain(customerName)
        await browser.sleep(5000)
    })

    afterEach(function(){

    })
})